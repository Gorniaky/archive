Execute Office 2021 Online Installer.cmd

Checksum
setup.exe SHA1 9e41855c6d75fb00ddb19ba98b2d08f56932e447