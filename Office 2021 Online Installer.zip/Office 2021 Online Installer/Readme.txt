Execute Office 2021 Online Installer.cmd

Checksum
Office 2021 Online Installer.cmd SHA1 255d6970bfa4f7006da67477a23754b700052444 Virus Total 0/58 2021-07-12 11:12:13 UTC
setup.exe                        SHA1 9e41855c6d75fb00ddb19ba98b2d08f56932e447 Virus Total 0/69 2021-06-06 08:26:46 UTC