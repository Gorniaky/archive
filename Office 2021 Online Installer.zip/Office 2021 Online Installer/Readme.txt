Execute Office 2021 Online Installer.cmd

Checksum
Office 2021 Online Installer.cmd SHA1 20b02ccf7470bcf5e19199151e84f0fac28cff8d Virus Total 0/57 2021-06-29 02:05:07 UTC
setup.exe                        SHA1 9e41855c6d75fb00ddb19ba98b2d08f56932e447 Virus Total 0/69 2021-06-06 08:26:46 UTC