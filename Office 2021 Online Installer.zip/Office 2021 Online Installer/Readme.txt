Execute install.cmd

checksum
setup.exe 9e41855c6d75fb00ddb19ba98b2d08f56932e447